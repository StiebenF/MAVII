#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include "SFMLRenderer.h"
#include <list>

using namespace sf;
class Game
{
private:
	// Propiedades de la ventana
	int _alto;
	int _ancho;
	RenderWindow* wnd;
	Color clearColor;

	// Objetos de box2d
	b2World* phyWorld;
	SFMLRenderer* debugRender;

	//tiempo de frame
	float frameTime;
	int fps;

	// Cuerpos de box2d
	b2Body* ballBody1;
	b2Body* ballBody2;
	b2Body* groundBody;

	b2MouseJoint* mouseJoint;

	const float SCALE = 100.0f; // Pixeles por metro

	Sprite ball1;
	Texture ballTex1;

	Sprite ball2;
	Texture ballTex2;

	Sprite background;
	Texture bgTex;

public:

	// Constructores, destructores e inicializadores
	Game(int ancho, int alto, std::string titulo);
	~Game(void);
	void InitGame();
	void InitPhysics();

	// Main game loop
	void Loop();
	void DrawGame();
	void UpdatePhysics();
	void DoEvents();

	void MouseClick(sf::Vector2i& pos);
	void MouseReleased();
	void MouseMoved(sf::Vector2i& pos);
};
