#include "Game.h"
#include "Box2DHelper.h"
#include <iostream>

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana y configuraci�n de propiedades
    _ancho = ancho;
    _alto = alto;
    wnd = new RenderWindow(VideoMode(_ancho, _alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    InitGame(); // Inicializaci�n de los objectos del juego
    InitPhysics(); // Inicializaci�n del motor de f�sica
}

// Bucle principal del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpiar la ventana
        DoEvents(); // Procesar eventos de entrada
        UpdatePhysics(); // Actualizar la simulaci�n f�sica
        DrawGame(); // Dibujar el juego
        wnd->display(); // Mostrar la ventana
    }
}

// Actualizaci�n de la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Simular el mundo f�sico
    phyWorld->ClearForces(); // Limpiar las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibujar el mundo f�sico para depuraci�n
}

// Dibujo de los elementos del juego
void Game::DrawGame()
{
    // Dibujar el fondo
    wnd->draw(background);

    // Dibujar la pelota
    ball.setPosition(
        (ballBody->GetPosition().x * SCALE) - ball.getGlobalBounds().width/2,
        (ballBody->GetPosition().y * SCALE) - ball.getGlobalBounds().height / 2);
    wnd->draw(ball);

    // Dibujar los obst�culos
    wnd->draw(blocker);
    wnd->draw(spike);
}

// Procesamiento de eventos de entrada
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cerrar la ventana si se presiona el bot�n de cerrar
            break;
        }
    }
}

void Game::InitGame()
{
    // Inicializar la pelota
    if (!ballTex.loadFromFile("../images/ball.png"))
        std::cerr << "Error loading texture!" << std::endl;
    ball.setTexture(ballTex);
    ball.setPosition(Vector2f(100.0f, 100.0f));

    // Inicializar el fondo
    if (!bgTex.loadFromFile("../images/background.png"))
        std::cerr << "Error loading texture!" << std::endl;
    background.setTexture(bgTex);
    background.setPosition(Vector2f(0.0f, 0.0f));

    // Inicializar los obst�culos
    if (!blockerTex.loadFromFile("../images/blocker.png"))
        std::cerr << "Error loading texture!" << std::endl;
    blocker.setTexture(blockerTex);
    blocker.setPosition(Vector2f(200.0f, 400.0f));

    if (!spikeTex.loadFromFile("../images/spike.png"))
        std::cerr << "Error loading texture!" << std::endl;
    spike.setTexture(spikeTex);
    spike.setPosition(Vector2f(500.0f, 200.0f));
}

// Inicializaci�n del motor de f�sica y los cuerpos del mundo f�sico
void Game::InitPhysics()
{
    // Inicializar el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Crear el suelo, el techo y las paredes est�ticas del mundo f�sico
    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    groundBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, (_alto - 35) / SCALE), 0.0f);

    b2Body* ceilingBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    ceilingBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, 35 / SCALE), 0.0f);

    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    leftWallBody->SetTransform(b2Vec2(35 / SCALE, (_alto / 2) / SCALE), 0.0f);

    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    rightWallBody->SetTransform(b2Vec2((_ancho - 35) / SCALE, (_alto / 2) / SCALE), 0.0f);

    // Crear los obst�culos
    b2Body* blockerBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        blocker.getGlobalBounds().width / SCALE,
        blocker.getGlobalBounds().height / SCALE);
    blockerBody->SetTransform(
        b2Vec2(
            (blocker.getPosition().x + (blocker.getGlobalBounds().width / 2)) / SCALE,
            (blocker.getPosition().y + (blocker.getGlobalBounds().height / 2)) / SCALE),
        0.0f);

    b2Body* spikeBody = Box2DHelper::CreateCircularStaticBody(
        phyWorld,
        (spike.getGlobalBounds().width / 2) / SCALE);
    spikeBody->SetTransform(
        b2Vec2(
            (spike.getPosition().x + (spike.getGlobalBounds().width / 2)) / SCALE,
            (spike.getPosition().y + (spike.getGlobalBounds().height / 2)) / SCALE),
        0.0f);

    // Crear la pelota
    ballBody = Box2DHelper::CreateCircularDynamicBody(
        phyWorld,
        (ball.getGlobalBounds().width / 2) / SCALE,
        1.0f,
        0.5,
        1.0f);

    ballBody->SetTransform(b2Vec2(400 / SCALE, 300 / SCALE), 0.0f);

    ballBody->ApplyLinearImpulseToCenter(b2Vec2(0.5f, 1.0f), true);
}

// Destructor de la clase
Game::~Game(void)
{ }