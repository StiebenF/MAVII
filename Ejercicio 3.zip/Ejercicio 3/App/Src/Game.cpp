#include "Game.h"
#include "Box2DHelper.h"
#include <iostream>


// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana y configuraci�n de propiedades
    _ancho = ancho;
    _alto = alto;
    wnd = new RenderWindow(VideoMode(_ancho, _alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    InitGame(); // Inicializaci�n de los objectos del juego
    InitPhysics(); // Inicializaci�n del motor de f�sica
}


// Bucle principal del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpiar la ventana
        DoEvents(); // Procesar eventos de entrada
        UpdatePhysics(); // Actualizar la simulaci�n f�sica
        DrawGame(); // Dibujar el juego
        wnd->display(); // Mostrar la ventana
    }
}


// Tomado de: https://github.com/erincatto/box2d/blob/main/testbed/test.cpp
class QueryCallback : public b2QueryCallback
{
public:
    QueryCallback(const b2Vec2& point)
    {
        m_point = point;
        m_fixture = NULL;
    }

    bool ReportFixture(b2Fixture* fixture) override
    {
        b2Body* body = fixture->GetBody();
        if (body->GetType() == b2_dynamicBody)
        {
            bool inside = fixture->TestPoint(m_point);
            if (inside)
            {
                m_fixture = fixture;

                // We are done, terminate the query.
                return false;
            }
        }

        // Continue the query.
        return true;
    }

    b2Vec2 m_point;
    b2Fixture* m_fixture;
};


// Actualizaci�n de la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Simular el mundo f�sico
    phyWorld->ClearForces(); // Limpiar las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibujar el mundo f�sico para depuraci�n
}


// Dibujo de los elementos del juego
void Game::DrawGame()
{
    // Dibujar el fondo
    wnd->draw(background);

    // Dibujar las pelotas
    ball1.setPosition(
        (ballBody1->GetPosition().x * SCALE) - ball1.getGlobalBounds().width / 2,
        (ballBody1->GetPosition().y * SCALE) - ball1.getGlobalBounds().height / 2);
    wnd->draw(ball1);

    ball2.setPosition(
        (ballBody2->GetPosition().x * SCALE) - ball2.getGlobalBounds().width / 2,
        (ballBody2->GetPosition().y * SCALE) - ball2.getGlobalBounds().height / 2);
    wnd->draw(ball2);
}


// Procesamiento de eventos de entrada
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::MouseButtonPressed:
            MouseClick(sf::Mouse::getPosition(*wnd));
            break;
        case Event::MouseButtonReleased:
            MouseReleased();
            break;
        case Event::MouseMoved:
            MouseMoved(sf::Mouse::getPosition(*wnd));
            break;
        case Event::Closed:
            wnd->close(); // Cerrar la ventana si se presiona el bot�n de cerrar
            break;
        }
    }
}

void Game::MouseClick(sf::Vector2i& pos)
{
    if (mouseJoint != NULL)
    {
        return;
    }

    // Escalar y convertir el vector de posici�n del mouse para box2d
    b2Vec2 point = b2Vec2(pos.x / SCALE, pos.y / SCALE);

    // Crear un AABB alrededor del mouse
    b2AABB box;
    box.lowerBound = point - b2Vec2(0.01f, 0.01f);
    box.upperBound = point + b2Vec2(0.01f, 0.01f);

    // Crear la clase del callback y relizar la consulta
    QueryCallback callback(point);
    phyWorld->QueryAABB(&callback, box);

    // Si se obtiene un fixture, crear un mouse joint
    if (callback.m_fixture)
    {
        float frequencyHz = 5.0f;
        float dampingRatio = 0.7f;

        b2Body* body = callback.m_fixture->GetBody();
        b2MouseJointDef mouseJointDef;
        mouseJointDef.bodyA = groundBody;
        mouseJointDef.bodyB = body;
        mouseJointDef.target = point;
        mouseJointDef.maxForce = 1000.0f * body->GetMass();
        b2LinearStiffness(mouseJointDef.stiffness, mouseJointDef.damping, frequencyHz, dampingRatio, mouseJointDef.bodyA, mouseJointDef.bodyB);

        mouseJoint = (b2MouseJoint*)phyWorld->CreateJoint(&mouseJointDef);
    }
}

void Game::MouseReleased()
{
    if (mouseJoint)
    {
        phyWorld->DestroyJoint(mouseJoint);
        mouseJoint = NULL;
    }
}


void Game::MouseMoved(sf::Vector2i& pos)
{
    // Escalar y convertir el vector de posici�n del mouse para box2d
    b2Vec2 point = b2Vec2(pos.x / SCALE, pos.y / SCALE);

    if (mouseJoint)
    {
        mouseJoint->SetTarget(point);
    }
}


void Game::InitGame()
{
    // Inicializar las pelotas
    if (!ballTex1.loadFromFile("../images/ball1.png"))
        std::cerr << "Error loading texture!" << std::endl;
    ball1.setTexture(ballTex1);
    ball1.setPosition(Vector2f(100.0f, 100.0f));

    if (!ballTex2.loadFromFile("../images/ball2.png"))
        std::cerr << "Error loading texture!" << std::endl;
    ball2.setTexture(ballTex2);
    ball2.setPosition(Vector2f(100.0f, 100.0f));

    // Inicializar el fondo
    if (!bgTex.loadFromFile("../images/background.png"))
        std::cerr << "Error loading texture!" << std::endl;
    background.setTexture(bgTex);
    background.setPosition(Vector2f(0.0f, 0.0f));

    mouseJoint = NULL;
}


// Inicializaci�n del motor de f�sica y los cuerpos del mundo f�sico
void Game::InitPhysics()
{
    // Inicializar el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    b2BodyDef groundBodyDef;
    groundBody = phyWorld->CreateBody(&groundBodyDef);

    // Crear el suelo, el techo y las paredes est�ticas del mundo f�sico
    b2Body* floorBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    floorBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, (_alto - 35) / SCALE), 0.0f);

    b2Body* ceilingBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    ceilingBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, 35 / SCALE), 0.0f);

    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    leftWallBody->SetTransform(b2Vec2(35 / SCALE, (_alto / 2) / SCALE), 0.0f);

    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    rightWallBody->SetTransform(b2Vec2((_ancho - 35) / SCALE, (_alto / 2) / SCALE), 0.0f);

    // Crear las pelotas
    ballBody1 = Box2DHelper::CreateCircularDynamicBody(
        phyWorld,
        (ball1.getGlobalBounds().width / 2) / SCALE,
        1.0f,
        0.5,
        0.5f);

    ballBody1->SetTransform(b2Vec2(300 / SCALE, 300 / SCALE), 0.0f);

    ballBody2 = Box2DHelper::CreateCircularStaticBody(
        phyWorld,
        ball2.getGlobalBounds().width / 2 / SCALE);

    ballBody2->SetTransform(b2Vec2(400 / SCALE, 300 / SCALE), 0.0f);

    // Crear un distance joint entre las dos pelotas
    b2DistanceJointDef jointDef;
    jointDef.Initialize(ballBody1, ballBody2, ballBody1->GetWorldCenter(),
        ballBody2->GetWorldCenter());
    jointDef.collideConnected = true;
    float frequencyHz = 4.0f;
    float dampingRatio = 0.5f;
    b2LinearStiffness(jointDef.stiffness, jointDef.damping, frequencyHz, dampingRatio, jointDef.bodyA, jointDef.bodyB);
    jointDef.minLength = 0.0f;
    jointDef.maxLength = 10.0f;
    jointDef.length = 1.0f;
    b2DistanceJoint* distJoint = (b2DistanceJoint*)phyWorld->CreateJoint(&jointDef);
}


// Destructor de la clase
Game::~Game(void)
{ }