#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include "SFMLRenderer.h"
#include <list>

using namespace sf;
class Game
{
private:
	// Propiedades de la ventana
	int _alto;
	int _ancho;
	RenderWindow* wnd;
	Color clearColor;

	// Objetos de box2d
	b2World* phyWorld;
	SFMLRenderer* debugRender;

	//tiempo de frame
	float frameTime;
	int fps;

	// Cuerpos de box2d
	b2Body* groundBody;
	b2Body* headBody;
	b2Body* bodyBody;
	b2Body* armRBody;
	b2Body* armLBody;
	b2Body* legRBody;
	b2Body* legLBody;

	b2MouseJoint* mouseJoint;

	const float SCALE = 100.0f; // Pixeles por metro

	// Sprites del ragdoll
	Sprite head;
	Texture headTex;
	Sprite body;
	Texture bodyTex;
	Sprite armL;
	Texture armLTex;
	Sprite legL;
	Texture legLTex;
	Sprite armR;
	Texture armRTex;
	Sprite legR;
	Texture legRTex;

	float ragdollX;
	float ragdollY;

	Sprite background;
	Texture bgTex;

public:

	// Constructores, destructores e inicializadores
	Game(int ancho, int alto, std::string titulo);
	~Game(void);
	void InitGame();
	void InitPhysics();

	// Main game loop
	void Loop();
	void DrawGame();
	void UpdatePhysics();
	void DoEvents();

	void MouseClick(sf::Vector2i& pos);
	void MouseReleased();
	void MouseMoved(sf::Vector2i& pos);
};
