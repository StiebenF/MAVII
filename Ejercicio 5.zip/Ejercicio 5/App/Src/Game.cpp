#include "Game.h"
#include "Box2DHelper.h"
#include <iostream>


// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana y configuraci�n de propiedades
    _ancho = ancho;
    _alto = alto;
    wnd = new RenderWindow(VideoMode(_ancho, _alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    InitGame(); // Inicializaci�n de los objectos del juego
    InitPhysics(); // Inicializaci�n del motor de f�sica
}


// Bucle principal del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpiar la ventana
        DoEvents(); // Procesar eventos de entrada
        UpdatePhysics(); // Actualizar la simulaci�n f�sica
        DrawGame(); // Dibujar el juego
        wnd->display(); // Mostrar la ventana
    }
}


// Tomado de: https://github.com/erincatto/box2d/blob/main/testbed/test.cpp
class QueryCallback : public b2QueryCallback
{
public:
    QueryCallback(const b2Vec2& point)
    {
        m_point = point;
        m_fixture = NULL;
    }

    bool ReportFixture(b2Fixture* fixture) override
    {
        b2Body* body = fixture->GetBody();
        if (body->GetType() == b2_dynamicBody)
        {
            bool inside = fixture->TestPoint(m_point);
            if (inside)
            {
                m_fixture = fixture;

                // We are done, terminate the query.
                return false;
            }
        }

        // Continue the query.
        return true;
    }

    b2Vec2 m_point;
    b2Fixture* m_fixture;
};


// Actualizaci�n de la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Simular el mundo f�sico
    phyWorld->ClearForces(); // Limpiar las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibujar el mundo f�sico para depuraci�n
}


// Dibujo de los elementos del juego
void Game::DrawGame()
{
    // Dibujar el fondo
    wnd->draw(background);

    // Dibujar el ragdoll
    // Cabeza
    head.setPosition(
        (headBody->GetPosition().x * SCALE),
        (headBody->GetPosition().y * SCALE));
    head.setRotation(headBody->GetAngle() * 180.0f / b2_pi);
    // Cuerpo
    body.setPosition(
        (bodyBody->GetPosition().x * SCALE),
        (bodyBody->GetPosition().y * SCALE));
    body.setRotation(bodyBody->GetAngle() * 180.0f / b2_pi);
    // Brazo derecho
    armR.setPosition(
        (armRBody->GetPosition().x * SCALE),
        (armRBody->GetPosition().y * SCALE));
    armR.setRotation(armRBody->GetAngle() * 180.0f / b2_pi);
    // Brazo izquierdo
    armL.setPosition(
        (armLBody->GetPosition().x * SCALE),
        (armLBody->GetPosition().y * SCALE));
    armL.setRotation(armLBody->GetAngle() * 180.0f / b2_pi);
    // Pierna derecha
    legR.setPosition(
        (legRBody->GetPosition().x * SCALE),
        (legRBody->GetPosition().y * SCALE));
    legR.setRotation(legRBody->GetAngle() * 180.0f / b2_pi);
    // Pierna izquierda
    legL.setPosition(
        (legLBody->GetPosition().x * SCALE),
        (legLBody->GetPosition().y * SCALE));
    legL.setRotation(legLBody->GetAngle() * 180.0f / b2_pi);

    wnd->draw(body);
    wnd->draw(armR);
    wnd->draw(armL);
    wnd->draw(legR);
    wnd->draw(legL);
    wnd->draw(head);
}


// Procesamiento de eventos de entrada
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::MouseButtonPressed:
            MouseClick(sf::Mouse::getPosition(*wnd));
            break;
        case Event::MouseButtonReleased:
            MouseReleased();
            break;
        case Event::MouseMoved:
            MouseMoved(sf::Mouse::getPosition(*wnd));
            break;
        case Event::Closed:
            wnd->close(); // Cerrar la ventana si se presiona el bot�n de cerrar
            break;
        }
    }
}

void Game::MouseClick(sf::Vector2i& pos)
{
    if (mouseJoint != NULL)
    {
        return;
    }

    // Escalar y convertir el vector de posici�n del mouse para box2d
    b2Vec2 point = b2Vec2(pos.x / SCALE, pos.y / SCALE);

    // Crear un AABB alrededor del mouse
    b2AABB box;
    box.lowerBound = point - b2Vec2(0.01f, 0.01f);
    box.upperBound = point + b2Vec2(0.01f, 0.01f);

    // Crear la clase del callback y relizar la consulta
    QueryCallback callback(point);
    phyWorld->QueryAABB(&callback, box);

    // Si se obtiene un fixture, crear un mouse joint
    if (callback.m_fixture)
    {
        float frequencyHz = 5.0f;
        float dampingRatio = 0.7f;

        b2Body* body = callback.m_fixture->GetBody();
        b2MouseJointDef mouseJointDef;
        mouseJointDef.bodyA = groundBody;
        mouseJointDef.bodyB = body;
        mouseJointDef.target = point;
        mouseJointDef.maxForce = 1000.0f * body->GetMass();
        b2LinearStiffness(mouseJointDef.stiffness, mouseJointDef.damping, frequencyHz, dampingRatio, mouseJointDef.bodyA, mouseJointDef.bodyB);

        mouseJoint = (b2MouseJoint*)phyWorld->CreateJoint(&mouseJointDef);
    }
}

void Game::MouseReleased()
{
    if (mouseJoint)
    {
        phyWorld->DestroyJoint(mouseJoint);
        mouseJoint = NULL;
    }
}


void Game::MouseMoved(sf::Vector2i& pos)
{
    // Escalar y convertir el vector de posici�n del mouse para box2d
    b2Vec2 point = b2Vec2(pos.x / SCALE, pos.y / SCALE);

    if (mouseJoint)
    {
        mouseJoint->SetTarget(point);
    }
}


void Game::InitGame()
{
    // Inicializar el ragdoll
    // Posici�n inicial
    ragdollX = 400.0f;
    ragdollY = 200.0f;
    // Cabeza
    if (!headTex.loadFromFile("../images/head.png"))
        std::cerr << "Error loading texture!" << std::endl;
    head.setTexture(headTex);
    head.setOrigin((sf::Vector2f)headTex.getSize() / 2.0f);
    // Cuerpo
    if (!bodyTex.loadFromFile("../images/body.png"))
        std::cerr << "Error loading texture!" << std::endl;
    body.setTexture(bodyTex);
    body.setOrigin((sf::Vector2f)bodyTex.getSize() / 2.0f);
    // Brazo derecho
    if (!armRTex.loadFromFile("../images/arm.png"))
        std::cerr << "Error loading texture!" << std::endl;
    armR.setTexture(armRTex);
    armR.setOrigin((sf::Vector2f)armRTex.getSize() / 2.0f);
    // Brazo izquierdo
    if (!armLTex.loadFromFile("../images/arm.png"))
        std::cerr << "Error loading texture!" << std::endl;
    armL.setTexture(armLTex);
    armL.setScale(Vector2f(-1.0f, 1.0f));
    armL.setOrigin((sf::Vector2f)armLTex.getSize() / 2.0f);
    // Pierna derecha
    if (!legRTex.loadFromFile("../images/leg.png"))
        std::cerr << "Error loading texture!" << std::endl;
    legR.setTexture(legRTex);
    legR.setOrigin((sf::Vector2f)legRTex.getSize() / 2.0f);
    // Pierna izquierda
    if (!legLTex.loadFromFile("../images/leg.png"))
        std::cerr << "Error loading texture!" << std::endl;
    legL.setTexture(legRTex);
    legL.setScale(Vector2f(-1.0f, 1.0f));
    legL.setOrigin((sf::Vector2f)legLTex.getSize() / 2.0f);

    // Inicializar el fondo
    if (!bgTex.loadFromFile("../images/background.png"))
        std::cerr << "Error loading texture!" << std::endl;
    background.setTexture(bgTex);
    background.setPosition(Vector2f(0.0f, 0.0f));

    mouseJoint = NULL;
}


// Inicializaci�n del motor de f�sica y los cuerpos del mundo f�sico
void Game::InitPhysics()
{
    // Inicializar el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    b2BodyDef groundBodyDef;
    groundBody = phyWorld->CreateBody(&groundBodyDef);

    // Crear el suelo, el techo y las paredes est�ticas del mundo f�sico
    b2Body* floorBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    floorBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, (_alto - 35) / SCALE), 0.0f);

    b2Body* ceilingBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    ceilingBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, 35 / SCALE), 0.0f);

    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    leftWallBody->SetTransform(b2Vec2(35 / SCALE, (_alto / 2) / SCALE), 0.0f);

    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    rightWallBody->SetTransform(b2Vec2((_ancho - 35) / SCALE, (_alto / 2) / SCALE), 0.0f);

    // Crear el ragdoll
    // Cabeza
    headBody = Box2DHelper::CreateCircularDynamicBody(
        phyWorld,
        (head.getGlobalBounds().width / 2) / SCALE,
        1.0f,
        0.5,
        0.5f);
    headBody->SetTransform(b2Vec2(ragdollX / SCALE, ragdollY / SCALE), 0.0f);
    // Cuerpo
    bodyBody = Box2DHelper::CreateRectangularDynamicBody(
        phyWorld,
        body.getGlobalBounds().width / SCALE,
        body.getGlobalBounds().height / SCALE,
        1.0f,
        0.5,
        0.5f);
    bodyBody->SetTransform(b2Vec2(ragdollX / SCALE, (ragdollY + 50.0f) / SCALE), 0.0f);
    // Brazo derecho
    armRBody = Box2DHelper::CreateRectangularDynamicBody(
        phyWorld,
        armR.getGlobalBounds().width / SCALE,
        armR.getGlobalBounds().height / SCALE,
        1.0f,
        0.5,
        0.5f);
    armRBody->SetTransform(b2Vec2((ragdollX + 40.0f) / SCALE, (ragdollY + 50.0f) / SCALE), -25.0f * b2_pi / 180.0f);
    // Brazo izquierdo
    armLBody = Box2DHelper::CreateRectangularDynamicBody(
        phyWorld,
        armL.getGlobalBounds().width / SCALE,
        armL.getGlobalBounds().height / SCALE,
        1.0f,
        0.5,
        0.5f);
    armLBody->SetTransform(b2Vec2((ragdollX - 40.0f) / SCALE, (ragdollY + 50.0f) / SCALE), 25.0f * b2_pi / 180.0f);
    // Pierna derecha
    legRBody = Box2DHelper::CreateRectangularDynamicBody(
        phyWorld,
        legR.getGlobalBounds().width / SCALE,
        legR.getGlobalBounds().height / SCALE,
        1.0f,
        0.5,
        0.5f);
    legRBody->SetTransform(b2Vec2((ragdollX + 20.0f) / SCALE, (ragdollY + 100.0f) / SCALE), 0.0f);
    // Pierna izquierda
    legLBody = Box2DHelper::CreateRectangularDynamicBody(
        phyWorld,
        legL.getGlobalBounds().width / SCALE,
        legL.getGlobalBounds().height / SCALE,
        1.0f,
        0.5,
        0.5f);
    legLBody->SetTransform(b2Vec2((ragdollX - 20.0f) / SCALE, (ragdollY + 100.0f) / SCALE), 0.0f);


    // Joints
    // Cabeza y cuerpo
    b2RevoluteJointDef revJointDef;
    revJointDef.lowerAngle = -15.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 15.0f * b2_pi / 180.0f;
    revJointDef.Initialize(headBody, bodyBody, b2Vec2(ragdollX / SCALE, (ragdollY + 20.0f) / SCALE));
    revJointDef.enableLimit = true;
    phyWorld->CreateJoint(&revJointDef);
    // Brazo derecho y cuerpo
    revJointDef.lowerAngle = -25.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 55.0f * b2_pi / 180.0f;
    revJointDef.Initialize(armRBody, bodyBody, b2Vec2((ragdollX + 30.0f) / SCALE, (ragdollY + 30.0f) / SCALE));
    revJointDef.enableLimit = true;
    phyWorld->CreateJoint(&revJointDef);
    // Brazo izquierdo y cuerpo
    revJointDef.lowerAngle = -55.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 25.0f * b2_pi / 180.0f;
    revJointDef.Initialize(armLBody, bodyBody, b2Vec2((ragdollX - 30.0f) / SCALE, (ragdollY + 30.0f) / SCALE));
    revJointDef.enableLimit = true;
    phyWorld->CreateJoint(&revJointDef);
    // Pierna derecha y cuerpo
    revJointDef.lowerAngle = -25.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 90.0f * b2_pi / 180.0f;
    revJointDef.Initialize(legRBody, bodyBody, b2Vec2((ragdollX + 15.0f) / SCALE, (ragdollY + 85.0f) / SCALE));
    revJointDef.enableLimit = true;
    phyWorld->CreateJoint(&revJointDef);
    // Pierna izquierda y cuerpo
    revJointDef.lowerAngle = -90.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 25.0f * b2_pi / 180.0f;
    revJointDef.Initialize(legLBody, bodyBody, b2Vec2((ragdollX - 15.0f) / SCALE, (ragdollY + 85.0f) / SCALE));
    revJointDef.enableLimit = true;
    phyWorld->CreateJoint(&revJointDef);
}


// Destructor de la clase
Game::~Game(void)
{ }