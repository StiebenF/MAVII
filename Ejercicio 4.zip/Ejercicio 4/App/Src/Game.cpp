#include "Game.h"
#include "Box2DHelper.h"
#include <iostream>

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana y configuraci�n de propiedades
    _ancho = ancho;
    _alto = alto;
    wnd = new RenderWindow(VideoMode(_ancho, _alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    InitGame(); // Inicializaci�n de los objectos del juego
    InitPhysics(); // Inicializaci�n del motor de f�sica
}

// Bucle principal del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpiar la ventana
        DoEvents(); // Procesar eventos de entrada
        UpdatePhysics(); // Actualizar la simulaci�n f�sica
        DrawGame(); // Dibujar el juego
        wnd->display(); // Mostrar la ventana
    }
}

// Actualizaci�n de la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Simular el mundo f�sico
    phyWorld->ClearForces(); // Limpiar las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibujar el mundo f�sico para depuraci�n
}

// Dibujo de los elementos del juego
void Game::DrawGame()
{
    // Dibujar el fondo
    wnd->draw(background);

    // Dibujar el bloque
    box.setPosition(
        (boxBody->GetPosition().x * SCALE) - box.getGlobalBounds().width / 2,
        (boxBody->GetPosition().y * SCALE) - box.getGlobalBounds().height / 2);
    wnd->draw(box);
}

// Procesamiento de eventos de entrada
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cerrar la ventana si se presiona el bot�n de cerrar
            break;
        }
    }

    // Controlar el movimiento de la caja con el teclado
    if (Keyboard::isKeyPressed(Keyboard::Up))
        boxBody->ApplyForceToCenter(b2Vec2(0.0f, -10.0f), true);
    if (Keyboard::isKeyPressed(Keyboard::Down))
        boxBody->ApplyForceToCenter(b2Vec2(0.0f, 1.0f), true);
    if (Keyboard::isKeyPressed(Keyboard::Left))
        boxBody->ApplyForceToCenter(b2Vec2(-1.0f, 0.0f), true);
    if (Keyboard::isKeyPressed(Keyboard::Right))
        boxBody->ApplyForceToCenter(b2Vec2(1.0f, 0.0f), true);

}

void Game::InitGame()
{
    // Inicializar el bloque
    if (!boxTex.loadFromFile("../images/box.png"))
        std::cerr << "Error loading texture!" << std::endl;
    box.setTexture(boxTex);
    box.setPosition(Vector2f(100.0f, 100.0f));

    // Inicializar el fondo
    if (!bgTex.loadFromFile("../images/background.png"))
        std::cerr << "Error loading texture!" << std::endl;
    background.setTexture(bgTex);
    background.setPosition(Vector2f(0.0f, 0.0f));
}

// Inicializaci�n del motor de f�sica y los cuerpos del mundo f�sico
void Game::InitPhysics()
{
    // Inicializar el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Crear el suelo, el techo y las paredes est�ticas del mundo f�sico
    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    groundBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, (_alto - 35) / SCALE), 0.0f);

    b2Body* ceilingBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        _ancho / SCALE,
        70 / SCALE);
    ceilingBody->SetTransform(b2Vec2((_ancho / 2) / SCALE, 35 / SCALE), 0.0f);

    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    leftWallBody->SetTransform(b2Vec2(35 / SCALE, (_alto / 2) / SCALE), 0.0f);

    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(
        phyWorld,
        70 / SCALE,
        _alto / SCALE);
    rightWallBody->SetTransform(b2Vec2((_ancho - 35) / SCALE, (_alto / 2) / SCALE), 0.0f);


    // Crear un bloque
    boxBody = Box2DHelper::CreateRectangularDynamicBody(
        phyWorld,
        box.getGlobalBounds().width / SCALE,
        box.getGlobalBounds().height / SCALE,
        1.0f,
        0.0f,
        0.1f);

    boxBody->SetTransform(b2Vec2(400 / SCALE, 300 / SCALE), 0.0f);
}

// Destructor de la clase
Game::~Game(void)
{ }