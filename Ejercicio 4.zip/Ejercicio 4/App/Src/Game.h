#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include "SFMLRenderer.h"
#include <list>

using namespace sf;
class Game
{
private:
	// Propiedades de la ventana
	int _alto;
	int _ancho;
	RenderWindow *wnd;
	Color clearColor;

	// Objetos de box2d
	b2World *phyWorld;
	SFMLRenderer *debugRender;

	//tiempo de frame
	float frameTime;
	int fps;

	// Cuerpo de box2d
	b2Body* boxBody;

	const float SCALE = 100.0f; // Pixeles por metro

	Sprite box;
	Texture boxTex;
	Sprite background;
	Texture bgTex;

public:

	// Constructores, destructores e inicializadores
	Game(int ancho, int alto,std::string titulo);
	~Game(void);
	void InitGame();
	void InitPhysics();

	// Main game loop
	void Loop();
	void DrawGame();
	void UpdatePhysics();
	void DoEvents();
};
