#pragma once
#include <SFML/Graphics.hpp>
#include "Box2DHelper.h"
#include "SFMLRenderer.h"

class Ragdoll
{
public:
	Ragdoll(float xPos, float yPos, float s);
	~Ragdoll();

	void Draw(sf::RenderWindow* wnd);
	void InitPhysics(b2World* phyWorld);

	b2Body* headBody;

private:
	b2Body* bodyBody;
	b2Body* armRBody;
	b2Body* armLBody;
	b2Body* legRBody;
	b2Body* legLBody;

	Sprite head;
	Texture headTex;
	Sprite body;
	Texture bodyTex;
	Sprite armL;
	Texture armLTex;
	Sprite legL;
	Texture legLTex;
	Sprite armR;
	Texture armRTex;
	Sprite legR;
	Texture legRTex;

	float ragdollX;
	float ragdollY;
	float scale;

	b2World* world;
};
