#include "Ragdoll.h"
#include <iostream>

Ragdoll::Ragdoll(float xPos, float yPos, float s)
{
    ragdollX = xPos;
    ragdollY = yPos;
    scale = s;

    // Cabeza
    if (!headTex.loadFromFile("../images/head.png"))
        std::cerr << "Error loading texture!" << std::endl;
    head.setTexture(headTex);
    head.setOrigin((sf::Vector2f)headTex.getSize() / 2.0f);
    // Cuerpo
    if (!bodyTex.loadFromFile("../images/body.png"))
        std::cerr << "Error loading texture!" << std::endl;
    body.setTexture(bodyTex);
    body.setOrigin((sf::Vector2f)bodyTex.getSize() / 2.0f);
    // Brazo derecho
    if (!armRTex.loadFromFile("../images/arm.png"))
        std::cerr << "Error loading texture!" << std::endl;
    armR.setTexture(armRTex);
    armR.setOrigin((sf::Vector2f)armRTex.getSize() / 2.0f);
    // Brazo izquierdo
    if (!armLTex.loadFromFile("../images/arm.png"))
        std::cerr << "Error loading texture!" << std::endl;
    armL.setTexture(armLTex);
    armL.setScale(Vector2f(-1.0f, 1.0f));
    armL.setOrigin((sf::Vector2f)armLTex.getSize() / 2.0f);
    // Pierna derecha
    if (!legRTex.loadFromFile("../images/leg.png"))
        std::cerr << "Error loading texture!" << std::endl;
    legR.setTexture(legRTex);
    legR.setOrigin((sf::Vector2f)legRTex.getSize() / 2.0f);
    // Pierna izquierda
    if (!legLTex.loadFromFile("../images/leg.png"))
        std::cerr << "Error loading texture!" << std::endl;
    legL.setTexture(legRTex);
    legL.setScale(Vector2f(-1.0f, 1.0f));
    legL.setOrigin((sf::Vector2f)legLTex.getSize() / 2.0f);
}

Ragdoll::~Ragdoll()
{
    world->DestroyBody(headBody);
    world->DestroyBody(bodyBody);
    world->DestroyBody(armLBody);
    world->DestroyBody(armRBody);
    world->DestroyBody(legLBody);
    world->DestroyBody(legRBody);
}

void Ragdoll::Draw(sf::RenderWindow* wnd)
{
    // Cabeza
    head.setPosition(
        (headBody->GetPosition().x * scale),
        (headBody->GetPosition().y * scale));
    head.setRotation(headBody->GetAngle() * 180.0f / b2_pi);
    // Cuerpo
    body.setPosition(
        (bodyBody->GetPosition().x * scale),
        (bodyBody->GetPosition().y * scale));
    body.setRotation(bodyBody->GetAngle() * 180.0f / b2_pi);
    // Brazo derecho
    armR.setPosition(
        (armRBody->GetPosition().x * scale),
        (armRBody->GetPosition().y * scale));
    armR.setRotation(armRBody->GetAngle() * 180.0f / b2_pi);
    // Brazo izquierdo
    armL.setPosition(
        (armLBody->GetPosition().x * scale),
        (armLBody->GetPosition().y * scale));
    armL.setRotation(armLBody->GetAngle() * 180.0f / b2_pi);
    // Pierna derecha
    legR.setPosition(
        (legRBody->GetPosition().x * scale),
        (legRBody->GetPosition().y * scale));
    legR.setRotation(legRBody->GetAngle() * 180.0f / b2_pi);
    // Pierna izquierda
    legL.setPosition(
        (legLBody->GetPosition().x * scale),
        (legLBody->GetPosition().y * scale));
    legL.setRotation(legLBody->GetAngle() * 180.0f / b2_pi);

    wnd->draw(body);
    wnd->draw(head);
    wnd->draw(armR);
    wnd->draw(armL);
    wnd->draw(legR);
    wnd->draw(legL);
}

void Ragdoll::InitPhysics(b2World* phyWorld)
{
    world = phyWorld;
    // Cabeza
    headBody = Box2DHelper::CreateCircularDynamicBody(
        world,
        (head.getGlobalBounds().width / 2) / scale,
        1.0f,
        0.5,
        0.5f);
    headBody->SetTransform(b2Vec2(ragdollX / scale, ragdollY / scale), 0.0f);
    // Cuerpo
    bodyBody = Box2DHelper::CreateRectangularDynamicBody(
        world,
        body.getGlobalBounds().width / scale,
        body.getGlobalBounds().height / scale,
        1.0f,
        0.5,
        0.5f);
    bodyBody->SetTransform(b2Vec2(ragdollX / scale, (ragdollY + 50.0f) / scale), 0.0f);
    // Brazo derecho
    armRBody = Box2DHelper::CreateRectangularDynamicBody(
        world,
        armR.getGlobalBounds().width / scale,
        armR.getGlobalBounds().height / scale,
        1.0f,
        0.5,
        0.5f);
    armRBody->SetTransform(b2Vec2((ragdollX + 40.0f) / scale, (ragdollY + 50.0f) / scale), -25.0f * b2_pi / 180.0f);
    // Brazo izquierdo
    armLBody = Box2DHelper::CreateRectangularDynamicBody(
        world,
        armL.getGlobalBounds().width / scale,
        armL.getGlobalBounds().height / scale,
        1.0f,
        0.5,
        0.5f);
    armLBody->SetTransform(b2Vec2((ragdollX - 40.0f) / scale, (ragdollY + 50.0f) / scale), 25.0f * b2_pi / 180.0f);
    // Pierna derecha
    legRBody = Box2DHelper::CreateRectangularDynamicBody(
        world,
        legR.getGlobalBounds().width / scale,
        legR.getGlobalBounds().height / scale,
        1.0f,
        0.5,
        0.5f);
    legRBody->SetTransform(b2Vec2((ragdollX + 20.0f) / scale, (ragdollY + 100.0f) / scale), 0.0f);
    // Pierna izquierda
    legLBody = Box2DHelper::CreateRectangularDynamicBody(
        world,
        legL.getGlobalBounds().width / scale,
        legL.getGlobalBounds().height / scale,
        1.0f,
        0.5,
        0.5f);
    legLBody->SetTransform(b2Vec2((ragdollX - 20.0f) / scale, (ragdollY + 100.0f) / scale), 0.0f);

    // Joints
// Cabeza y cuerpo
    b2RevoluteJointDef revJointDef;
    revJointDef.lowerAngle = -15.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 15.0f * b2_pi / 180.0f;
    revJointDef.Initialize(headBody, bodyBody, b2Vec2(ragdollX / scale, (ragdollY + 20.0f) / scale));
    revJointDef.enableLimit = true;
    world->CreateJoint(&revJointDef);
    // Brazo derecho y cuerpo
    revJointDef.lowerAngle = -25.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 55.0f * b2_pi / 180.0f;
    revJointDef.Initialize(armRBody, bodyBody, b2Vec2((ragdollX + 30.0f) / scale, (ragdollY + 30.0f) / scale));
    revJointDef.enableLimit = true;
    world->CreateJoint(&revJointDef);
    // Brazo izquierdo y cuerpo
    revJointDef.lowerAngle = -55.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 25.0f * b2_pi / 180.0f;
    revJointDef.Initialize(armLBody, bodyBody, b2Vec2((ragdollX - 30.0f) / scale, (ragdollY + 30.0f) / scale));
    revJointDef.enableLimit = true;
    world->CreateJoint(&revJointDef);
    // Pierna derecha y cuerpo
    revJointDef.lowerAngle = -25.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 90.0f * b2_pi / 180.0f;
    revJointDef.Initialize(legRBody, bodyBody, b2Vec2((ragdollX + 15.0f) / scale, (ragdollY + 85.0f) / scale));
    revJointDef.enableLimit = true;
    world->CreateJoint(&revJointDef);
    // Pierna izquierda y cuerpo
    revJointDef.lowerAngle = -90.0f * b2_pi / 180.0f;
    revJointDef.upperAngle = 25.0f * b2_pi / 180.0f;
    revJointDef.Initialize(legLBody, bodyBody, b2Vec2((ragdollX - 15.0f) / scale, (ragdollY + 85.0f) / scale));
    revJointDef.enableLimit = true;
    world->CreateJoint(&revJointDef);
}
